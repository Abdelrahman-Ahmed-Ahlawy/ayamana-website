const express = require('express');
const router = express.Router();
const Article = require('../models/Article');

// @route   GET api/articles
// @desc    Get all articles
// @access  Public
router.get('/', async (req, res) => {
  try {
    const articles = await Article.find().sort({ date: -1 });
    res.json(articles);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET api/articles/:id
// @desc    Get single article
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const article = await Article.findById(req.params.id);
    if (!article) {
      return res.status(404).json({ msg: 'Article not found' });
    }
    res.json(article);
  } catch (err) {
    console.error(err.message);
    if (err.kind === 'ObjectId') {
      return res.status(404).json({ msg: 'Article not found' });
    }
    res.status(500).send('Server Error');
  }
});

// @route   POST api/articles
// @desc    Add new article
// @access  Public (should be protected in production)
router.post('/', async (req, res) => {
  const { title, author, content } = req.body;

  try {
    const newArticle = new Article({
      title,
      author,
      content,
    });

    const article = await newArticle.save();
    res.json(article);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   PUT api/articles/:id
// @desc    Update article
// @access  Public (should be protected in production)
router.put('/:id', async (req, res) => {
  const { title, author, content } = req.body;

  try {
    let article = await Article.findById(req.params.id);
    if (!article) {
      return res.status(404).json({ msg: 'Article not found' });
    }

    article = await Article.findByIdAndUpdate(
      req.params.id,
      { $set: { title, author, content } },
      { new: true }
    );

    res.json(article);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   DELETE api/articles/:id
// @desc    Delete article
// @access  Public (should be protected in production)
router.delete('/:id', async (req, res) => {
  try {
    let article = await Article.findById(req.params.id);
    if (!article) {
      return res.status(404).json({ msg: 'Article not found' });
    }

    await Article.findByIdAndRemove(req.params.id);
    res.json({ msg: 'Article removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
