const express = require('express');
const router = express.Router();

// Contact model (you can create a separate model file if needed)
const mongoose = require('mongoose');

const ContactSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
  },
  message: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

const Contact = mongoose.model('Contact', ContactSchema);

// @route   POST api/contact
// @desc    Submit contact form
// @access  Public
router.post('/', async (req, res) => {
  const { name, email, phone, message } = req.body;

  try {
    const newContact = new Contact({
      name,
      email,
      phone,
      message,
    });

    const contact = await newContact.save();
    
    // Here you can add email notification logic
    // For example, send email to admin about new contact form submission
    
    res.json({ 
      success: true, 
      message: 'تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.',
      contact: contact 
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ 
      success: false, 
      message: 'حدث خطأ في الخادم. يرجى المحاولة مرة أخرى.' 
    });
  }
});

// @route   GET api/contact
// @desc    Get all contact messages (for admin)
// @access  Public (should be protected in production)
router.get('/', async (req, res) => {
  try {
    const contacts = await Contact.find().sort({ date: -1 });
    res.json(contacts);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
