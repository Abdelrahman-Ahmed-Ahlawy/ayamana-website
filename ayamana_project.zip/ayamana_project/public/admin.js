// Admin Panel JavaScript

// Show/Hide sections
function showSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    // Show selected section
    document.getElementById(sectionId).style.display = 'block';
    
    // Update active nav link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    event.target.classList.add('active');
}

// Dark mode toggle
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    const toggleBtn = document.getElementById('darkModeToggle');
    
    if (isDark) {
        toggleBtn.innerHTML = '<i class="bi bi-sun"></i> الوضع العادي';
        localStorage.setItem('darkMode', 'enabled');
    } else {
        toggleBtn.innerHTML = '<i class="bi bi-moon"></i> الوضع المظلم';
        localStorage.setItem('darkMode', 'disabled');
    }
}

// Load dark mode preference
document.addEventListener('DOMContentLoaded', function() {
    if (localStorage.getItem('darkMode') === 'enabled') {
        document.body.classList.add('dark-mode');
        document.getElementById('darkModeToggle').innerHTML = '<i class="bi bi-sun"></i> الوضع العادي';
    }
    
    // Initialize charts
    initializeCharts();
    
    // Load data
    loadServices();
    loadClients();
    loadArticles();
});

// Initialize Charts
function initializeCharts() {
    // Visitors Chart
    const visitorsCtx = document.getElementById('visitorsChart').getContext('2d');
    new Chart(visitorsCtx, {
        type: 'line',
        data: {
            labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
            datasets: [{
                label: 'الزوار',
                data: [120, 190, 300, 500, 200, 300],
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Services Chart
    const servicesCtx = document.getElementById('servicesChart').getContext('2d');
    new Chart(servicesCtx, {
        type: 'doughnut',
        data: {
            labels: ['تطوير المواقع', 'تحليل البيانات', 'التسويق الرقمي', 'الاستشارات'],
            datasets: [{
                data: [30, 25, 25, 20],
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Detailed Analytics Chart
    const analyticsCtx = document.getElementById('detailedAnalyticsChart').getContext('2d');
    new Chart(analyticsCtx, {
        type: 'bar',
        data: {
            labels: ['الأسبوع 1', 'الأسبوع 2', 'الأسبوع 3', 'الأسبوع 4'],
            datasets: [{
                label: 'المبيعات',
                data: [12, 19, 3, 5],
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }, {
                label: 'العملاء الجدد',
                data: [8, 11, 6, 9],
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Services Management
async function loadServices() {
    try {
        const response = await fetch('/api/services');
        const services = await response.json();
        
        const tableBody = document.getElementById('servicesTable');
        tableBody.innerHTML = '';
        
        services.forEach((service, index) => {
            const row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${service.title}</td>
                    <td>${service.description}</td>
                    <td><i class="bi ${service.icon}"></i></td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="editService('${service._id}')">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteService('${service._id}')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });
        
        document.getElementById('totalServices').textContent = services.length;
    } catch (error) {
        console.error('Error loading services:', error);
        // Load sample data if API fails
        loadSampleServices();
    }
}

function loadSampleServices() {
    const sampleServices = [
        { _id: '1', title: 'تطوير المواقع', description: 'تطوير مواقع ويب متجاوبة وحديثة', icon: 'bi-code-slash' },
        { _id: '2', title: 'تحليل البيانات', description: 'تحليل البيانات وإنشاء التقارير', icon: 'bi-graph-up' },
        { _id: '3', title: 'التسويق الرقمي', description: 'خدمات التسويق الإلكتروني', icon: 'bi-megaphone' }
    ];
    
    const tableBody = document.getElementById('servicesTable');
    tableBody.innerHTML = '';
    
    sampleServices.forEach((service, index) => {
        const row = `
            <tr>
                <td>${index + 1}</td>
                <td>${service.title}</td>
                <td>${service.description}</td>
                <td><i class="bi ${service.icon}"></i></td>
                <td>
                    <button class="btn btn-sm btn-warning">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

async function addService() {
    const title = document.getElementById('serviceTitle').value;
    const description = document.getElementById('serviceDescription').value;
    const icon = document.getElementById('serviceIcon').value;
    
    if (!title || !description || !icon) {
        alert('يرجى ملء جميع الحقول');
        return;
    }
    
    try {
        const response = await fetch('/api/services', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, description, icon })
        });
        
        if (response.ok) {
            alert('تمت إضافة الخدمة بنجاح');
            document.getElementById('addServiceForm').reset();
            bootstrap.Modal.getInstance(document.getElementById('addServiceModal')).hide();
            loadServices();
        } else {
            alert('حدث خطأ في إضافة الخدمة');
        }
    } catch (error) {
        console.error('Error adding service:', error);
        alert('حدث خطأ في الاتصال بالخادم');
    }
}

// Clients Management
async function loadClients() {
    try {
        const response = await fetch('/api/clients');
        const clients = await response.json();
        
        const tableBody = document.getElementById('clientsTable');
        tableBody.innerHTML = '';
        
        clients.forEach((client, index) => {
            const row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${client.name}</td>
                    <td>${client.email}</td>
                    <td>${client.phone}</td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="editClient('${client._id}')">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteClient('${client._id}')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });
        
        document.getElementById('totalClients').textContent = clients.length;
    } catch (error) {
        console.error('Error loading clients:', error);
        loadSampleClients();
    }
}

function loadSampleClients() {
    const sampleClients = [
        { _id: '1', name: 'أحمد محمد', email: 'ahmed@example.com', phone: '01234567890' },
        { _id: '2', name: 'فاطمة علي', email: 'fatima@example.com', phone: '01234567891' },
        { _id: '3', name: 'محمد حسن', email: 'mohamed@example.com', phone: '01234567892' }
    ];
    
    const tableBody = document.getElementById('clientsTable');
    tableBody.innerHTML = '';
    
    sampleClients.forEach((client, index) => {
        const row = `
            <tr>
                <td>${index + 1}</td>
                <td>${client.name}</td>
                <td>${client.email}</td>
                <td>${client.phone}</td>
                <td>
                    <button class="btn btn-sm btn-warning">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

async function addClient() {
    const name = document.getElementById('clientName').value;
    const email = document.getElementById('clientEmail').value;
    const phone = document.getElementById('clientPhone').value;
    
    if (!name || !email || !phone) {
        alert('يرجى ملء جميع الحقول');
        return;
    }
    
    try {
        const response = await fetch('/api/clients', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, phone })
        });
        
        if (response.ok) {
            alert('تمت إضافة العميل بنجاح');
            document.getElementById('addClientForm').reset();
            bootstrap.Modal.getInstance(document.getElementById('addClientModal')).hide();
            loadClients();
        } else {
            alert('حدث خطأ في إضافة العميل');
        }
    } catch (error) {
        console.error('Error adding client:', error);
        alert('حدث خطأ في الاتصال بالخادم');
    }
}

// Articles Management
async function loadArticles() {
    try {
        const response = await fetch('/api/articles');
        const articles = await response.json();
        
        const tableBody = document.getElementById('articlesTable');
        tableBody.innerHTML = '';
        
        articles.forEach((article, index) => {
            const row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${article.title}</td>
                    <td>${article.author}</td>
                    <td>${new Date(article.date).toLocaleDateString('ar-EG')}</td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="editArticle('${article._id}')">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteArticle('${article._id}')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });
        
        document.getElementById('totalArticles').textContent = articles.length;
    } catch (error) {
        console.error('Error loading articles:', error);
        loadSampleArticles();
    }
}

function loadSampleArticles() {
    const sampleArticles = [
        { _id: '1', title: 'مستقبل التكنولوجيا', author: 'أحمد محمد', date: new Date() },
        { _id: '2', title: 'تحليل البيانات الحديث', author: 'فاطمة علي', date: new Date() },
        { _id: '3', title: 'التسويق الرقمي', author: 'محمد حسن', date: new Date() }
    ];
    
    const tableBody = document.getElementById('articlesTable');
    tableBody.innerHTML = '';
    
    sampleArticles.forEach((article, index) => {
        const row = `
            <tr>
                <td>${index + 1}</td>
                <td>${article.title}</td>
                <td>${article.author}</td>
                <td>${article.date.toLocaleDateString('ar-EG')}</td>
                <td>
                    <button class="btn btn-sm btn-warning">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

async function addArticle() {
    const title = document.getElementById('articleTitle').value;
    const author = document.getElementById('articleAuthor').value;
    const content = document.getElementById('articleContent').value;
    
    if (!title || !author || !content) {
        alert('يرجى ملء جميع الحقول');
        return;
    }
    
    try {
        const response = await fetch('/api/articles', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, author, content })
        });
        
        if (response.ok) {
            alert('تمت إضافة المقال بنجاح');
            document.getElementById('addArticleForm').reset();
            bootstrap.Modal.getInstance(document.getElementById('addArticleModal')).hide();
            loadArticles();
        } else {
            alert('حدث خطأ في إضافة المقال');
        }
    } catch (error) {
        console.error('Error adding article:', error);
        alert('حدث خطأ في الاتصال بالخادم');
    }
}
